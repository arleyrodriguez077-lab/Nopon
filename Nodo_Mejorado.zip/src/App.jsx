import React, { useState } from 'react';
import CrisisButton from './CrisisButton.jsx';

function App() {
  const [posts, setPosts] = useState([
    { id: 1, text: "Hoy me siento con ganas de avanzar en mis estudios.", user: "Usuario_928" }
  ]);
  const [isRecapacitacion, setIsRecapacitacion] = useState(false);

  const handleSimularInfraccion = () => {
    setIsRecapacitacion(true);
    setTimeout(() => setIsRecapacitacion(false), 5000);
  };

  return (
    <div className={`min-h-screen p-4 transition-colors duration-1000 ${isRecapacitacion ? 'bg-[#E1D5F8]' : 'bg-[#F8F9FA]'}`}>
      {isRecapacitacion ? (
        <div className="flex flex-col items-center justify-center h-screen text-center">
          <h2 className="text-2xl font-bold mb-4 text-[#2D3436]">Tiempo de Recapacitación</h2>
          <p className="text-[#2D3436]">Tu mensaje no se alinea con el apoyo de la comunidad. Reflexionemos un momento.</p>
        </div>
      ) : (
        <>
          <nav className="flex justify-between items-center mb-8 border-b border-gray-300 pb-4">
            <h1 className="text-2xl font-bold text-[#2D3436]">NODO</h1>
            <button onClick={handleSimularInfraccion} className="text-xs text-gray-500 underline">Simular infracción</button>
          </nav>
          <main className="max-w-xl mx-auto">
            {posts.map(post => (
              <div key={post.id} className="bg-white p-6 rounded-xl shadow-sm mb-4 border-l-4 border-[#74B9FF]">
                <p className="text-lg mb-4 text-[#2D3436]">{post.text}</p>
                <div className="flex gap-4">
                  <button className="text-sm text-[#2D3436] hover:text-[#D63031]">Apoyo</button>
                  <button className="text-sm text-[#2D3436] hover:text-[#D63031]">Entiendo</button>
                  <button className="text-sm text-[#2D3436] hover:text-[#D63031]">Fortaleza</button>
                </div>
              </div>
            ))}
          </main>
          <CrisisButton />
        </>
      )}
    </div>
  );
}

export default App;